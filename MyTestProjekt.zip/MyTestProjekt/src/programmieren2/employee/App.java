package programmieren2.employee;

public class App {
    public static void main(String[] args) {
        Employee e1 = new Employee();
        e1.printEmpData();
        Employee e2 = new Employee(1, "sara", "kaufen", 2100, 100, true);
        e2.printEmpData();
        System.out.println(e2.isEquale(e1));
    }
}
