package programmieren2.employee;

public class Employee {
    int emp_ID;
    String name;
    String depart;
    double salary;
    double bonus;
    boolean resident;

    public Employee() {
        emp_ID = 50;
        name = "No Name";
        depart = "Sales";
        salary = 2000;
        bonus = 125;
        resident = true;
    }


    public Employee(int e, String n) {
        emp_ID = e;
        name = n;
    }
public Employee(int e, String n, boolean r){
 this (e, n);
 resident = r;
}
public Employee(int e, String n, String d, double s, double b, boolean r){
        this (e, n, r);
        depart= d;
        salary = s;
        bonus = b;
}
public boolean isEquale( Employee e1){
        if (this.salary == e1.salary && this.depart == e1.depart){
            return true;
        }else {
            return false;
        }
}
/*
    public void setSalary(double s) {
        salary = s;
    }
/*

    public void setS&B(double salary, double bonus){
        this.salary = salary;
        this.bonus = bonus;
    }

 */

    public void printEmpData() {
        System.out.println(emp_ID + " " + name + " " + depart + " " + salary + " " + bonus + " " + resident);
    }
}
