package programmieren2.uebungen.uebung3.uebung3_2;

import java.util.HashMap;

public class Blackjack {
    private HashMap<Player, Integer> players;

    public Blackjack() {
        players = new HashMap<Player, Integer>();
    }

    public boolean add(Player player){
        if (players.containsKey(player)){
            return false;
        }
        players.put(player, 0);
        return true;
    }

    public boolean addCard(Player player, Integer cardValue){
        if (!players.containsKey(player)){
            return false;
        }
        Integer value = players.get(player);
        value += cardValue;
        players.put(player, value);
        return true;
    }

    public Integer getValue(Player player){
        return players.get(player);
    }

    public Player getWinner(){
        Player w =null;
        int punkte = 0;

        for (Player p : players.keySet()){
            int punkteP = players.get(p);
            if (punkteP <= 21){
                if (punkteP >punkte){
                    punkte = punkteP;
                    w=p;
                }else {
                    if (punkteP == punkte){
                        w = null;
                    }
                }
            }
        }
        return w;
    }

    @Override
    public String toString() {
        return "Blackjack{" +
                "players=" + players +
                '}';
    }
}
