package programmieren2.uebungen.uebung3;

public class J {
}
