package programmieren2.uebungen.uebung3.uebung3_1;

public class Event {
    private String Title;
    private String Ort;
    private double Eintrittspris;

    public Event(String title, String ort, double eintrittspris) {
        Title = title;
        Ort = ort;
        Eintrittspris = eintrittspris;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getOrt() {
        return Ort;
    }

    public void setOrt(String ort) {
        Ort = ort;
    }

    public double getEintrittspris() {
        return Eintrittspris;
    }

    public void setEintrittspris(double eintrittspris) {
        Eintrittspris = eintrittspris;
    }

    @Override
    public String toString() {
        return Title +" " + Ort + " "+ Eintrittspris;
    }
}
