package programmieren2.uebungen.uebung3.uebung3_1;

import java.util.ArrayList;
import java.util.HashMap;

public class EventKalender {
    private ArrayList<Event> events;

    public EventKalender() {
        events = new ArrayList<Event>();
    }

    public void add(Event e) {
        events.add(e);
    }

    public Event getByTitle(String title) {
        for (Event e : events) {
            if (e.getTitle().equals(title)) {
                return e;
            }
        }
        return null;
    }

    public ArrayList<Event> getByOrt(String ort) {
        ArrayList<Event> erg = new ArrayList<Event>();
        for (Event e : events) {
            if (e.getOrt().equals(ort)) {
                erg.add(e);
            }
        }
        return erg;
    }

    public ArrayList<Event> getByEintrittsPreis(double min, double max) {
        ArrayList<Event> erg = new ArrayList<Event>();
        for (Event e : events) {
            if (e.getEintrittspris() >= min && e.getEintrittspris() <= max) {
                erg.add(e);
            }
        }
        return erg;
    }

    public Event getMostExpensiveByOrt(String ort) {
        Event mostExp = null;
        for (Event e : events) {
            if (e.getOrt().equals(ort) && (mostExp == null || e.getEintrittspris() > mostExp.getEintrittspris())) {
                mostExp = e;
            }
        }
        return mostExp;
    }

    public double getAvgPreisByOrt(String ort) {
        double sum = 0;
        int anzahl = 0;
        for (Event e : events) {
            if (e.getOrt().equals(ort)) {
                sum += e.getEintrittspris();
                anzahl += 1;
            }
        }
        return sum / anzahl;
    }

    public HashMap<String, Integer> getCountEventsByOrt() {
        HashMap<String, Integer> map = new HashMap<String, Integer>();

        for (Event e : events) {
            if (map.containsKey(e.getOrt())) {
                map.put(e.getOrt(), 1+ map.get(e.getOrt()));
            } else {
                map.put(e.getOrt(), 1);

            }
        }
        return map;
    }

    public HashMap<String, Double> getSumPriceEventsByOrt() {
        HashMap<String, Double> erg = new HashMap<String, Double>();
        for (Event e : events) {
            if (erg.containsKey(e.getOrt())){
                erg.put(e.getOrt(), e.getEintrittspris() + erg.get(e.getOrt()));
            }else {
                erg.put(e.getOrt(),e.getEintrittspris());
            }
        }
        return erg;
    }
}
