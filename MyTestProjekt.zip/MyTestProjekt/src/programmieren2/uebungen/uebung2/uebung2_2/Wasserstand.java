package programmieren2.uebungen.uebung2.uebung2_2;

public class Wasserstand {
    private int Id;
    private String GewasserName;
    private String Ort;
    private double messWert;
    private double messWertFuerAlarmierung;
    private int zeitPunkt;

    public Wasserstand(int id, String gewasserName, String ort, double messWert, double messWertFuerAlarmierung, int zeitPunkt) {
        Id = id;
        GewasserName = gewasserName;
        this.Ort = ort;
        this.messWert = messWert;
        this.messWertFuerAlarmierung = messWertFuerAlarmierung;
        this.zeitPunkt = zeitPunkt;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getGewasserName() {
        return GewasserName;
    }

    public void setGewasserName(String gewasserName) {
        GewasserName = gewasserName;
    }

    public String getOrt() {
        return Ort;
    }

    public void setOrt(String ort) {
        this.Ort = ort;
    }

    public double getMessWert() {
        return messWert;
    }

    public void setMessWert(double messWert) {
        this.messWert = messWert;
    }

    public double getMessWertFuerAlarmierung() {
        return messWertFuerAlarmierung;
    }

    public void setMessWertFuerAlarmierung(double messWertFuerAlarmierung) {
        this.messWertFuerAlarmierung = messWertFuerAlarmierung;
    }

    public int getZeitPunkt() {
        return zeitPunkt;
    }

    public void setZeitPunkt(int zeitPunkt) {
        this.zeitPunkt = zeitPunkt;
    }

    @Override
    public String toString() {
        return Id + " " + GewasserName + " " + Ort + " " + messWert + " " + messWertFuerAlarmierung + " " + zeitPunkt;
    }

}
