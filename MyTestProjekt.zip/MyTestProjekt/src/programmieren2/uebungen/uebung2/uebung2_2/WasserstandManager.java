package programmieren2.uebungen.uebung2.uebung2_2;

import java.util.ArrayList;

public class WasserstandManager {
    private ArrayList<Wasserstand> wasserstands;

    public WasserstandManager() {
        wasserstands = new ArrayList<Wasserstand>();
    }

    public void addWasserObjekte(Wasserstand w) {
        wasserstands.add(w);
    }

    public Wasserstand findById(int id) {
        for (Wasserstand w : wasserstands) {
            if (id == w.getId()) {
                return w;
            }
        }
        return null;
    }

    public ArrayList<Wasserstand> findAllByGewaesser(String gewaesserName) {
        ArrayList<Wasserstand> nameOfWasserstaende = new ArrayList<>();
        for (Wasserstand w : wasserstands) {
            if (w.getGewasserName().equals(gewaesserName)) {
                nameOfWasserstaende.add(w);
            }
        }
        return nameOfWasserstaende;
    }

    public Wasserstand findLastWasserstand(String gewaesserName){
        Wasserstand lastWasser = null;
        for (Wasserstand w: findAllByGewaesser(gewaesserName)){
            if (lastWasser==null ||  w.getZeitPunkt() > lastWasser.getZeitPunkt()){
                lastWasser = w;
            }
        }
        return lastWasser;
    }

   public ArrayList<Wasserstand> findForAlarmierung(){
        ArrayList<Wasserstand> alarmWasser = new ArrayList<>();
        for (Wasserstand w: wasserstands){
            if (w.getMessWert() >= w.getMessWertFuerAlarmierung()){
                alarmWasser.add(w);
            }
        }
        return alarmWasser;
   }

   public double calcMittlererWasserstand(String gewaesserName, String ort){
        double durchschnitt = 0;
        double sum = 0;
        int count = 0;
        for (Wasserstand w: wasserstands){
            if (w.getGewasserName().equals(gewaesserName) && w.getOrt().equals(ort)) {
              sum +=  w.getMessWert();
              count +=1;
            }
            durchschnitt = sum / count;
        }
        return durchschnitt;
   }

   public ArrayList<Wasserstand> findByZeitpunkt(int von, int bis, String gewaesserName, String ort){
        ArrayList<Wasserstand> erg = new ArrayList<>();
        for (Wasserstand w: wasserstands){
            if (w.getGewasserName().equals(gewaesserName)&& w.getOrt().equals(ort) && (w.getZeitPunkt() > von)&&(w.getZeitPunkt() < bis)){
                erg.add(w);
            }
        }
        return erg;
   }
}
