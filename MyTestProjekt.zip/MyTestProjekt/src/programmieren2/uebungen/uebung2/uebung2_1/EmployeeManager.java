package programmieren2.uebungen.uebung2.uebung2_1;

import programmieren2.uebungen.uebung2.uebung2_1.Employee;

import java.util.ArrayList;
import java.util.List;

public class EmployeeManager {
    private List<Employee> employees;

    public EmployeeManager() {
        employees = new ArrayList<>();
    }

    public void addEmployee(Employee e){
        employees.add(e);
    }

    public Employee findByEmpNumber(int number){
        for (Employee e: employees){
            if(number == e.getEmpNumber()){
                return e;
            }
        }
        return null;
    }

    public ArrayList<Employee> findByDepartment(String department){
        ArrayList<Employee> empOfDepartment = new ArrayList<>();
        for (Employee e: employees){
            if (department.equals(e.getDepartment())){
                empOfDepartment.add(e);
            }
        }
        return empOfDepartment;
    }

    public Employee findByMaxSalary(){
        double max = 0;
        Employee maxE = null;
        for (Employee e: employees){
            if (e.getEmpNumber()> max){
                max = e.getSalary();
                maxE = e;
            }
        }
        return maxE;
    }


}
