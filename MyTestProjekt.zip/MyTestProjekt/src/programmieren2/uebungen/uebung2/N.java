package programmieren2.uebungen.uebung2;

public class N {
}
