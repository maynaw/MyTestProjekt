package programmieren2.uebungen.uebung1.uebung1_2;

public enum Direction {
    UP,RIGHT,DOWN,LEFT
}
