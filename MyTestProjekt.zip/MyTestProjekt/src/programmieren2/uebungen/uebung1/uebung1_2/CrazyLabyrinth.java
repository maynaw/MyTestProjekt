package programmieren2.uebungen.uebung1.uebung1_2;

public class CrazyLabyrinth {

    public  boolean checkPathConsistency(LabyrinthTile[] path) {
        for (int i = 0; i < path.length; i++) {
            if ((path[i].getExit() == Direction.UP) && (path[i].getEntry() != Direction.DOWN)) {
                return false;
            }
            if ((path[i].getExit() == Direction.DOWN) && (path[i].getEntry() != Direction.UP)) {
                return false;
            }
            if ((path[i].getExit() == Direction.LEFT) && (path[i].getEntry() != Direction.RIGHT)) {
                return false;
            }
            if ((path[i].getExit() == Direction.RIGHT) && (path[i].getEntry() != Direction.LEFT)) {
                return false;
            }
        }
        return true;
    }
}
