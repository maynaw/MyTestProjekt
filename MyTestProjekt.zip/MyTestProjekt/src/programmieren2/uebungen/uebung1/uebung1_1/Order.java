package programmieren2.uebungen.uebung1.uebung1_1;

import programmieren2.uebungen.uebung1.uebung1_1.Article;

import java.util.Arrays;

public class Order {
    private int nrArticles;
    private int capacityOrder;
    private Article[] articles;

    public Order(int nrArticles, int capacityOrder, Article[] articles) {
        this.nrArticles = 0;
        this.capacityOrder = capacityOrder;
        this.articles = new Article[capacityOrder];
    }

    public int getNrArticles() {
        return nrArticles;
    }

    public int getCapacityOrder() {
        return capacityOrder;
    }

    public void addArticle(Article a) {
        if (nrArticles >= capacityOrder) {
            increaseArray();
        }
        articles[nrArticles++] = a;
        nrArticles++;
    }

    public int findMostExpensiveArticle() {
        int highest = 0;
        for (int i = 0; i < articles.length; i++) {
            if (articles[i].getPrice() > articles[highest].getPrice()) {
                highest = i;
            }
        }
        return highest + 1;
    }

    public int findMostExpensiveOrderPosition() {
        int highestOrder = 0;
        for (int i = 0; i < articles.length; i++) {
            if (articles[i].getPrice() * nrArticles > articles[highestOrder].getPrice() * nrArticles) {
                highestOrder = i;
            }
        }
        return highestOrder + 1;
    }

    public double sumOrder() {
        double sum = 0;
        for (Article a : articles) {
            sum += (a.getPrice() * a.getNumber());
        }
        return sum;
    }

    public double calculateTax() {
        double steuer = 0;

        for (Article a : articles) {
            if (a.getPrice() < 20) {
                steuer = (a.getNumber() * 5 / 100);
            } else {
                steuer = (a.getNumber() * 20 / 100);
            }
            steuer += steuer;
        }
        return steuer;
    }

    public double sumOrderWithTax() {
        return calculateTax() + sumOrder();
    }

    private void increaseArray() {
        System.out.println("capacity increased");
        Article[] newArt = new Article[capacityOrder + 10];

        for (int i = 0; i < nrArticles; i++) {
            newArt[i] = articles[i];
        }
        articles = newArt;
        capacityOrder = capacityOrder + 10;
    }

    public void removeArticle(int nr) {
        if (nr > 0 && nr <= nrArticles) {
            for (int i = nr - 1; i < nrArticles - 1; i++) {
                articles[i] = articles[i + 1];
            }
            articles[nr - 1] = null;
            --nrArticles;
        }
    }

    @Override
    public String toString() {
        return "Order{" +
                "articles=" + Arrays.toString(articles) +
                '}';
    }
}