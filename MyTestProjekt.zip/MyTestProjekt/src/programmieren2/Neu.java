package programmieren2;

public class Neu {
}
