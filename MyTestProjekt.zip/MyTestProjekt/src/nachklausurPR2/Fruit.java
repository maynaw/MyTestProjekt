package nachklausurPR2;

public enum Fruit {
}
