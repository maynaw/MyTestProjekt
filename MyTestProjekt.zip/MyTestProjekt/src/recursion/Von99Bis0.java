package recursion;

public class Von99Bis0 {
    public static void main(String[] args) {
        decrement(5);
    }

    public static void decrement(int i) {
        System.out.println(i);
        i--;
        if (i >= 0) {
         //   System.out.println(i);
            decrement(i);
        }
    }
}
