package uno;
/*
an object of type Hand represents a hand of cards. The cards belong to the class Card.
Ahand is empty when it is created, and any number of cards can be added to it.
 */
import java.util.ArrayList;

public class Hand {
    private ArrayList<Card> hand; // the cards in the hand.
    // create a hand that is initially empty.
    public Hand(){
        hand = new ArrayList<Card>();
    }

    // remove all cards from the hand, leaving it empty.
    public void clear(){
        hand.clear();
    }
  /* Add a card to the hand. It is added at the end of the current hand.
  at param c the non-null card to be added.
  at throws NullPointerException if the parameter c is null.
   */
    public void addCard(Card c){
        if (c == null) {
            throw new NullPointerException("Can't dadd a null card to a hand.");
        }
        hand.add(c);
    }

}
