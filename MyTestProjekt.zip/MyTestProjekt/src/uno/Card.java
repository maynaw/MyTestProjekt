package uno;

import com.sun.jdi.Value;


public class Card {
    enum Color {
        blue, green, yellow, red, Wild;
        private static final Color[] colors = Color.values();

        public static Color getColor(int i) {
            return Color.colors[i];
        }
    }

    enum Value {
        zero, one, tow, three, four, five, six, seven, eight, nine, Drawtwo, Skip, Reverse, Wild, Wild_Four;
        private static final Value[] values = Value.values();

        public static Value getValue(int i) {
            return Value.values[i];
        }
    }

    private final Color color;
    private final Value value;

    public Card(Color color, Value value) {
        this.color = color;
        this.value = value;
    }

    public Color getColor() {
        return this.color;
    }

    public Value getValue() {
        return this.value;
    }

    @Override
    public String toString() {
        return color + " " + value;
    }
}