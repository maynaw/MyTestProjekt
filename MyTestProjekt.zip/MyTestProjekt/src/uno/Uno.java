package uno;

public class Uno {
}
