package uno;
/*
import javax.swing.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/*
the Deck class consistes of 108 Uno Cards. There are four suits, Red, Green, Blue and Yellow
Each consisting of one 0 card, two 1 cards, 2s, 3s, 4s, 5s, 6s, 7s, 8s, 9s, two Draw two cards; two skip cards, and two Reverse cards.
in addition, there are four wwild cards and four wild Draw four cards.

public class Deck {

    private Card[] cards;
    private int cardsInDeck;


    public Deck() {
        cards = new Card[108];
    }

    public void reset() {
        Card.Color[] colors = Card.Color.values();
        cardsInDeck = 0;

        for (int i = 0; i < colors.length - 1; i++) {
            Card.Color color = colors[i];
            cards[cardsInDeck++] = new Card(color, Card.Value.getValue(0));

            for (int j = 1; j < 10; j++) {
                cards[cardsInDeck++] = new Card(color, Card.Value.getValue(j));
                cards[cardsInDeck++] = new Card(color, Card.Value.getValue(j));
            }
            Card.Value[] values = new Card.Value[] {Card.Value.Drawtwo,Card.Value.Skip,Card.Value.Reverse};
            for (Card.Value value : values){
                cards[cardsInDeck++] = new Card(color, value);
                cards[cardsInDeck++] = new Card(color, value);
            }
        }
        // Add wild Cards: wild wild and wild drawFour
        Card.Value[] values = Card.Value[] {Card.Value.Wild, Card.Value.Wild_Four;}
        for (Card.Value value : values){
            for (int i = 0; i<4; i++){
                cards[cardsInDeck++] = new Card(Card.Color.Wild, value);
            }
        }
    }
    // @ param cards (stockpile)
    // replaces the deck with an arraylist of Cards (the stockpile)
    public void replaceDeckWith(ArrayList<Card> cards){
        this.cards = cards.toArray(new Card[cards.size()]);
        this.cardsInDeck = this.cards.length;
    }
    // @return true if there are no cards in the deck
    public boolean isEmpty(){
        return cardsInDeck == 0;
    }
    public void shuffle(){
        int n = cards.length;
        Random random = new Random();
        for (int i = 0; i<cards.length;i++){

            // Get a drandom index of the array past the current index
            // ... the argument is an exclusive bound
            // swap the random element with the present element

            int randomValue = i + random.nextInt(n - i);
            Card randomCard = cards[randomValue];
            cards[randomValue] = cards[i];
            cards[i] = randomCard;
        }
    }
    public Card drawCard() throws IllegalArgumentException{
        if (isEmpty()){
            throw new IllegalArgumentException("Cannot draw a card since there are no cards in the deck");
        }
        return cards[--cardsInDeck];
    }

    public ImageIcon drawCardImage() throws IllegalArgumentException{
        if (isEmpty()){
            throw new IllegalArgumentException("Cannot draw a card since the deck is empty");
        }
        return new ImageIcon(cards[--cardsInDeck].toString() + ".png");
    }
    public Card[] drawCard(int n){
        if (n<0){
            throw new IllegalArgumentException("Must draw positive cards but tried to draw " + n + "cards.");
        }
        if (n>cardsInDeck){
            throw new IllegalArgumentException("Cannot draw " + n + " cards since there are only " + cardsInDeck + "cards.");
        }
        Card[] ret = new Card[n];

        for (int i = 0; i<n; i++){
            ret[i] = cards[--cardsInDeck];
        }
        return ret;
    }
}

*/