package programmieren1.uebungsBeispiele3;

public class NarzisstischeZahlen {
    public static void main(String[] args) {
/*
    }

    public static void narzisstischeZahlen(int zahl) {
        zahl = 0;
        for (int i = 1; i <= 1000; i++) {
            int digi = i % 10;
            if (i>0){
            i /= 10;
        int sum = digi +


    }

 */
}
}
