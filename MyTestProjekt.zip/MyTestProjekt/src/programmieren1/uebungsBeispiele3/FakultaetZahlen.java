package programmieren1.uebungsBeispiele3;

public class FakultaetZahlen {
    public static void main(String[] args) {
        suchFakultät(3);
    }

    public static void suchFakultät(int zahl) {
        System.out.print(zahl + "! = ");
        int f = 1;
        for (int x = 1; x <= zahl; x++) {
            f *= x;
            System.out.print(x);
            if (x < zahl) {
                System.out.print(" * ");
            }
            if (x == zahl) {
                System.out.println(" = " + f);

            }

        /*
        System.out.println(f);
*/
        }
    }
}