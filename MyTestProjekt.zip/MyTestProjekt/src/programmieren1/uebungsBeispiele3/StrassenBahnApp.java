package programmieren1.uebungsBeispiele3;

public class StrassenBahnApp {
    public static void main(String[] args) {
        dauerZumZiel(6, 1);
    }

    public static void dauerZumZiel(int zeit, int station) {
        if (station == 1) {
            zeit = 20;
            System.out.println("Du bist noch in Station " + station + " und bis zum dein Ziel bleibt " + zeit);
        } else if (station == 2) {
            zeit = 16;
            System.out.println("Du bist noch in Station " + station + " und bis zum dein Ziel bleibt " + zeit);
        } else if (station == 3) {
            zeit = 15;
            System.out.println("Du bist noch in Station " + station + " und bis zum dein Ziel bleibt " + zeit);
        } else if (station == 4) {
            zeit = 10;
            System.out.println("Du bist noch in Station " + station + " und bis zum dein Ziel bleibt " + zeit);
        } else if (station == 5) {
            zeit = 3;
            System.out.println("Du bist noch in Station " + station + " und bis zum dein Ziel bleibt " + zeit);
        } else {
            System.out.println("Du bist in Station " + station + "Diese ist dein Ziel");
        }
    }
}



