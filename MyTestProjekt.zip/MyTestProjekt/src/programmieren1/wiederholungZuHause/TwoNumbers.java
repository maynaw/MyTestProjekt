package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class TwoNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
            int number1, number2;
        System.out.println("enter two numbers");
        number1 = scanner.nextInt();
        number2 = scanner.nextInt();
        if (number1 == number2)
            System.out.println("the numbers are equal");
        else if (number1 > number2)
            System.out.println("the first number is grater than the second number");
        else System.out.println("the second number is grater than the first number");
    }
}
