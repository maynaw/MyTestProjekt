package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class Factorial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter number to get factorial");
        int factorial = 1;
        int number = scanner.nextInt();
        System.out.print(number +"! = ");
        for (int i  = 1; i <= number; i++){
            factorial = factorial *i;
            System.out.print( i );
            if (i<number){
                System.out.print(" *");
            }
        }
        System.out.println(" = " + factorial);
    }
}
