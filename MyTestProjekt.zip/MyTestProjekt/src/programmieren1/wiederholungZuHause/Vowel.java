package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class Vowel {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char ch;
        System.out.println("enter character");
        ch = scanner.next().charAt(0);
        switch (ch) {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                System.out.println("the letter is vowel");
                break;
            default:
                System.out.println("the letter is not vowel");
        }
    }
}
