package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class PositiveOrNegative {
    public static void main(String[] args) {
        // test if the scan number positive or negative?
        Scanner scanner = new Scanner(System.in);
        double number;
        System.out.println("enter the number to test");
        number = scanner.nextDouble();
        if (number >= 0 )
            System.out.println("the number is positive");
        else System.out.println("the number is negative");
    }
}
