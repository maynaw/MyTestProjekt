package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class GradeAverageDoWhile {
    public static void main(String[] args) {
        int sum= 0, grade, counter = 1;
        Scanner scanner = new Scanner(System.in);

        do {
            System.out.println("enter the grade number: " + counter);
            grade = scanner.nextInt();
            counter++;
            sum = sum + grade;
        }while (counter<=6);
        System.out.println("The average of grade is: " + sum/counter);
    }
}
