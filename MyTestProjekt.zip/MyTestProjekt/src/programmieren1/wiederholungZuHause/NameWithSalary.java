package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class NameWithSalary {
    public static void main(String[] args) {
        /*
        Scanner scanner = new Scanner(System.in);
        String name;
        float salary, netSalary;
        System.out.println("please enter your name");
        name = scanner.nextLine();
        System.out.println("please enter your salary");
        salary = scanner.nextFloat();
        netSalary = salary - (salary * 0.10f);
        System.out.println("the net salary is : " + netSalary);

         */

        int i = 9, j = 4;
      //  System.out.println((float) i/j);
        ++i;
        j++;
        System.out.println(i);
        System.out.println(j);
    }
}
