package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class ArrayMethods {
    public static void main(String[] args) {
        int[] array = new int[5];
        fillArray(array);
        printArray(array);
        System.out.println("++++++++++++++++++");
        System.out.println(search(array,8));

    }

    public static void fillArray(int[] list) {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < list.length; i++) {
            System.out.println("enter number" + (i + 1));
            list[i] = scanner.nextInt();
        }
    }

    public static void printArray(int[] list) {
        for (int i = 0; i < list.length; i++) {
            System.out.print(list[i] + " ");
            System.out.println();
        }
    }

    public static int search(int[] list, int target) {
        for (int i = 0; i < list.length; i++) {
            if (list[i] == target) {
                return i;
            }
        }
        return -1;
    }

}
