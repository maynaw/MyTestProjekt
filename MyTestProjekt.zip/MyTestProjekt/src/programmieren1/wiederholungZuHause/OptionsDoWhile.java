package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class OptionsDoWhile {
    public static void main(String[] args) {
        int num1 = 10, num2=20;
        int option;
        Scanner scanner = new Scanner(System.in);

        do{
            System.out.println("1: add the tow numbers");
            System.out.println("2: subtract the tow numbers");
            System.out.println("3: Multiply the two numbers");
            System.out.println("4: divide the tow numbers");
            System.out.println("0: good bye");
            option = scanner.nextInt();
            switch (option){
                case 1:
                    System.out.println("the sum of the tow numbers: " +( num1 + num2));
                    break;
                case 2:
                    System.out.println("the subtract of the tow numbers: " +( num1 - num2));
                    break;
                case 3:
                    System.out.println("the Multiple of the tow numbers: " + (num1 * num2));
                    break;
                case 4:
                    System.out.println("the division of the tow numbers: " +(double)( num1 / num2));
                    break;
                case 0:
                    System.out.println("good bye");
                    break;
                default:
                    System.out.println("invalid number");
                    break;
            }
        }while (option != 0);
    }
}
