package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class Break {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int  number, sum = 0;
        for (int i = 1; i <=5;){
            System.out.println("enter number " + i);
            number = scanner.nextInt();
            if (number<0){
                System.out.println("negative numbers are not allowed ");
                continue;
            }
            sum += number;
            i++;
        }
        System.out.println("sum = " + sum);
    }
}
//test