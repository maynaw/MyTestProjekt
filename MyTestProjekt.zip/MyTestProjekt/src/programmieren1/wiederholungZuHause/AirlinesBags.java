package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class AirlinesBags {
    public static void main(String[] args) {

        char airlineClass;
        float weight = 0, strafe = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the class of passenger");
        airlineClass = scanner.next().charAt(0);
        System.out.println("enter the weight of bag");
        weight = scanner.nextInt();
        switch (airlineClass) {
            case 'f':
                if (weight > 30) {
                    strafe = (weight - 30) * 10;
                }
                break;
            case 'b':
                if (weight > 25) {
                    strafe = (weight - 25) * 10;
                }
                break;
            case 'e':
                if (weight > 20) {
                    strafe = (weight - 20) * 10;
                }
                break;
            default:
                System.out.println("invalid class");
        }
        System.out.println("the excess baggage charge is: " + strafe);
    }
}
