package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class SumOfEachEvenAndOdd {
    public static void main(String[] args) {
        int sumEven=0, sumOdd = 0, number = 0;
        Scanner scanner = new Scanner(System.in);
        for (int i = 1; i <=10; i++){
            System.out.println("enter the number " + i);
            number = scanner.nextInt();
            if (number %2 == 0){
                sumEven += number;
            }else if (number%2 !=0){
                sumOdd += number;
            }
        }
        System.out.println("The sum of the odd numbers is: " + sumOdd);
        System.out.println("The sum of the Even numbers is: " + sumEven);
    }
}
