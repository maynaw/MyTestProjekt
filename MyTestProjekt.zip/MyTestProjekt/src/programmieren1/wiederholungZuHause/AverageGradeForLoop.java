package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class AverageGradeForLoop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int grade = 0, sum = 0, i = 1;
        for ( i = 1; i <= 6; i++) {
            System.out.println("enter the grade number: " + i);
            grade = scanner.nextInt();
            sum += grade;
        }
        System.out.println("the average of the grades is: " + (sum / i));
    }
}
