package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class DemontionalAraay {
    public static void main(String[] args) {
        int[][] array = new int[5][3];
        fillDemontionalArray(array);
        System.out.println("++++++++++++++++++++++++++");
        printArray(array);
        System.out.println("the sum of array numbers is: " + sumArray(array));
/*
        for (int column = 0; column < array[2].length; column++) {
            array[2][column] = 7;

            System.out.println(array[2][column]);
        }

 */
    }

    public static void fillDemontionalArray(int[][] list) {
        Scanner scanner = new Scanner(System.in);
        int counter = 1;
        for (int r = 0; r < list.length; r++) {
            for (int c = 0; c < list[r].length; c++) {
                System.out.println("enter number" + counter);
                list[r][c] = scanner.nextInt();
                counter++;

            }
        }
    }

    public static void printArray(int[][] list) {
        for (int r = 0; r < list.length; r++) {
            for (int c = 0; c < list[r].length; c++) {
                System.out.print(list[r][c] + " , ");
            }
        }
    }

    public static int sumArray(int[][] list) {
        int sum = 0;
        for (int r = 0; r < list.length; r++) {
            for (int c = 0; c < list[r].length; c++) {
                sum += list[r][c];
            }
        }
        return sum;
    }
}
//hallo