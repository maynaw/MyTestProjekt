package programmieren1.wiederholungZuHause;

import java.lang.reflect.Array;
import java.util.Scanner;

public class PositiveIntegerArray {
    public static void main(String[] args) {
        int[] positive = new int[5];
        Scanner scanner = new Scanner(System.in);
        int sum = 0, counter = 0;
        for (int i = 0; i < positive.length; i++) {
            System.out.println("enter  number " + (i + 1));
            positive[i] = scanner.nextInt();
            if (positive[i] > 0) {
                sum += positive[i];
               counter  +=1;
            }
        }
        System.out.println("the sum of numbers is: " + sum);
        System.out.println("the average of numbers is: " +( (double)sum / counter));
    }
}
