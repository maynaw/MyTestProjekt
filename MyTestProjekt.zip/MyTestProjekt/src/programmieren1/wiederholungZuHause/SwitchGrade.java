package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class SwitchGrade {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the grade");
        char grade;
        grade = scanner.next().charAt(0);
        switch (grade){
            case 'a':
                System.out.println("excellent");
                break;
            case 'b':
                System.out.println("very good");
                break;
            case 'c':
                System.out.println("good");
                break;
            case 'D':
                System.out.println("fair");
                break;
            case 'f':
                System.out.println("failed");
                break;
            default:
                System.out.println("invalid");
        }
    }
}
