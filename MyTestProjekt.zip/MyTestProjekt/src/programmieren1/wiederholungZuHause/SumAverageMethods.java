package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class SumAverageMethods {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num1, num2, sum;
        enterNumber();
        num1 = scanner.nextInt();
        enterNumber();
        num2 = scanner.nextInt();
        sum = sumTowNumbers(num1, num2);
        display(sum, average(num1,num2));

    }

    public static int sumTowNumbers(int i, int j) {

        return i + j;
    }

    public static double average(int i, int j) {

        return sumTowNumbers(i, j) / 2;
    }

    public static void enterNumber() {
        System.out.println("enter a number ");
    }

    public static void display(int s, double a) {
        System.out.println("the sum of numbers is " + s);
        System.out.println("the average of numbers is " + a);
    }
}
