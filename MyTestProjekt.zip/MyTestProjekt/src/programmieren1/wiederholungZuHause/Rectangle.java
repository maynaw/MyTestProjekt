package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class Rectangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int width, length, area;

        System.out.println("bitte geben Sie die Length ein");
        length = scanner.nextInt();
        System.out.println("bitte geben Sie die Width ein");
        width = scanner.nextInt();
        area = width * length;
        System.out.println("die area ist gleich: " + area);
    }
}
