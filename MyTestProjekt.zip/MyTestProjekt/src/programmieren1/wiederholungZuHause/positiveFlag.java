package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class positiveFlag {
    public static void main(String[] args) {
        int number, sum = 0;
        boolean positive= true;
        Scanner scanner = new Scanner(System.in);

        while (positive == true){
            System.out.println("enter positive numbers");
            number = scanner.nextInt();
            if (number <0){
                positive = false;
            }
            else {
                sum += number;
            }
        }
        System.out.println("the sum of input numbers is: " + sum);
    }
}
