package programmieren1.wiederholungZuHause;

import java.util.Scanner;

public class GuessNumber {
    public static void main(String[] args) {
        int guess, rand;
        rand = (int) (Math.random() *100);
        Scanner scanner = new Scanner(System.in);
        boolean guessed = true;
        System.out.println("the random number is " + rand);
        while (guessed == true){
            System.out.println("enter a number from 1 to 100");
            guess = scanner.nextInt();
            if (guess < rand){
                System.out.println("The guess is too small");
            }else if (guess >rand){
                System.out.println("The guess is too large");
            }else
            guessed = false;
        }
        System.out.println("you win");
    }
}
