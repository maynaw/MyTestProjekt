package programmieren1.forLoop;

public class SumsFor {
    public static void main(String[] args) {
        System.out.println(sum(1, 10));
    }
    public static int sum(int startnum, int lastnum){
        int sum = 0;
        for (int i = 0; i< lastnum; i++){
            sum += startnum;
            startnum += 1;
        }
        return sum;
    }
}
