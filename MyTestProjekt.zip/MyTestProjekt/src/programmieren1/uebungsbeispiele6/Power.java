package programmieren1.uebungsbeispiele6;

public class Power {
    public static void main(String[] args) {
        System.out.println(powerSimpl(10,3));

    }

    public static int powerSimpl(int x, int n) {
        int erg = 1;
        for (int i = 0; i < n; i++) {
            erg = erg * x;
        }
        return erg;
    }

}
