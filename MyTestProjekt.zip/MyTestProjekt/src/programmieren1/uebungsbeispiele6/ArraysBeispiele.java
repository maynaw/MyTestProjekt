package programmieren1.uebungsbeispiele6;

import java.util.Arrays;

public class ArraysBeispiele {
    public static void main(String[] args) {
        int[] test = {9, -7, -5, 10};
        System.out.println(findeKleinsteZahl(test));

        int[][] m = {{2, 2, 4, 4}, {1, 2, 4, -1}, {1, 4, 3, -1}, {4, 2, 3, -1}};
        System.out.println(summeGegendiagonale(m));

        // float[][] test1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        System.out.println(Arrays.toString(mittelwerte(m)));

        String[] w1 = {"Hansi", "Susi", "Toni", "Magda"};
        String[] w2 = {"Kerstin", "Hansi", "Toni", "Michaela"};
        System.out.println(Arrays.toString(luckyLooser(w1, w2)));


        int[][] sm = {{1,50},{3,30},{2,10},{1,40}};
        int[][] sales = smartphoneSales(sm);
        for (int[]s : sales){
            System.out.println(Arrays.toString(s));
        }
    }

    public static int findeKleinsteZahl(int[] array) {
        int smal = array[0];
        int index = 0;

        for (int i = 1; i < array.length; ++i) {

            if (array[i] < smal) {
                index = i;
                smal = array[i];
            }
        }
        return index;
    }

    public static int summeGegendiagonale(int[][] m) {
        int sum = 0;

        for (int i = 0; i < m.length; ++i) {
            sum += m[i][m.length - i - 1];
        }
        return sum;
    }

    public static double[] mittelwerte(int[][] arr) {
        double[] mittelwerte = new double[arr.length];
        for (int z = 0; z < arr.length; ++z) {
            double sum = 0;
            for (int s = 0; s < arr[z].length; ++s) {
                sum += arr[z][s];
                // mw = sum / arr[z].length;
            }
            mittelwerte[z] = sum / arr.length;
        }
        return mittelwerte;
    }

     public static String[] luckyLooser(String[] first, String[] second) {
          String[] l = new String[first.length > second.length ? first.length : second.length];
          int nextIdx = 0;
          for (int f = 0; f < first.length; ++f) {
              for (int s = 0; s < second.length; ++s) {
                  if (first[f].equals(second[s])) {
                      l[nextIdx++] = first[f];
                      break;
                  }
              }
          }
          return l;
      }

    public static int[][] smartphoneSales(int[][] sales) {
        int[][] sums = new int[10][2];

        for (int z = 0; z < sales.length; ++z) {
            sums[sales[z][0] - 1][0] = sales[z][0];
            sums[sales[z][0] - 1][1] += sales[z][1];
        }
        return sums;
    }


}
