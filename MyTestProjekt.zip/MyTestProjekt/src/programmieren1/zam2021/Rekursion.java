package programmieren1.zam2021;
/*
public class Rekursion {
    public static void main(String[] args) {
        walk(5, 1);
    }

    public static void walk(int countStep, int currentStep) {
        if (currentStep <= countStep) {
            currentStep = currentStep + 1;
            countStep =step + 1;
            System.out.println("Step backward: " + currentStep);
             walk();

        int countStep=0;
        for (int currentStep = 1; currentStep <= step; ++currentStep) {
            countStep = countStep +1;
            System.out.println("Step forward: " + currentStep);

            }for (int currentStep = step- 1; currentStep>0; --currentStep){
            System.out.println("Step backward: " + currentStep);
            countStep = countStep +1;



        }
        // System.out.println("gesammte Schritte: " + countStep);
    }
}
*/

