package programmieren1.fibonacciBeispiel;

public class Fibonacci {
    public static void main(String[] args) {
        int ersteFib = 0;
        int zweiteFib = 1;
        fibonacci(ersteFib, zweiteFib);
    }

    public static void fibonacci(int a, int b) {

        int erg = a + b;
        if (erg > 1000) {
            return ;
        } else {
            System.out.println(erg);
            a = b;
            b = erg;
            fibonacci(a, b);
        }
    }
}
