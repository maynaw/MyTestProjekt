package programmieren1.dowhile;

public class DoCount {
    public static void main(String[] args) {
doCount(90);
    }
    public static void doCount(int startnr){
        do {
            System.out.println(startnr);
            startnr = startnr+ 1;

        }while (startnr<= 100);
    }
}
