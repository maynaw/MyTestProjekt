package programmieren1.uebungsBeispiele7;

public class Rechteck {
    public double laenge;
    public double breite;
    public double hoehe;

    public double flaeche() {
        return laenge * breite;

    }

    public void skaliere(double f) {
        laenge *= f;
        breite *= f;
        hoehe *= f;
    }

    public double volumen() {
        return laenge * breite * hoehe;
    }

    public double oberFlaeche() {
        return 2 * breite * laenge + 2 * laenge * hoehe + 2 * hoehe * breite;
    }
}
