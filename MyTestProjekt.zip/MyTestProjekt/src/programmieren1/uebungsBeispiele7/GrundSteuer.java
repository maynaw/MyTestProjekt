package programmieren1.uebungsBeispiele7;

public class GrundSteuer {

    public double grundsteuerBerechnen(int[][] grundSt) {
        double summe = 0;
        double[] price = {3.20, 2.10, 0.90};

        for (int i = 0; i < grundSt.length; i++) {
            summe += price[grundSt[i][0] - 1] * grundSt[i][1] * grundSt[i][2];

        }
        return summe;
    }
    public double[] grundsteuerZuordnen(int[][] g, int[] owner){
        double[] erg = new double[25];
        double[] price = {3.20, 2.10, 0.90};

        for (int i = 0; i < g.length; i++){
            erg[owner[i]] += price[g[i][0]-1]* g[i][1]*g[i][2];
        }
        return erg;
    }
}
