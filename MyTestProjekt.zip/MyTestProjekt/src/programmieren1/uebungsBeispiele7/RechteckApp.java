package programmieren1.uebungsBeispiele7;

public class RechteckApp {
    public static void main(String[] args) {
        Rechteck r = new Rechteck();
        r.breite = 2;
        r.laenge = 10;
        r.hoehe = 4;

        System.out.println(r.flaeche());
        r.skaliere(2);
        System.out.println(r.oberFlaeche());
        System.out.println(r.volumen());
    }
}
