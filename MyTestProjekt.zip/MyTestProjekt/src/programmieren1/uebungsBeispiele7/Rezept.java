package programmieren1.uebungsBeispiele7;

public class Rezept {
    public int anzahlPersoonen;
    public String[] zutatenName;
    public double[][] zutaten;

    public boolean allergisch(String zutat) {
        for (int z = 0; z < zutatenName.length; z++) {
            if (zutatenName[z].equals(zutat)) {
                return true;
            }
        }
        return false;
    }

    public boolean laktoseFrei() {
        boolean found = false;
        for (int z = 0; z < zutatenName.length; z++) {
            if (zutatenName[z].equals("milch") || zutatenName[z].equals("käse")) {
                found = true;
                zutaten[z][0] = 0;
                zutaten[z][1] = 0.0;
            }
        }
        return found;
    }


}