package programmieren1.uebungsBeispiele7;

public class QuaderApp {
    public static void main(String[] args) {
        Quader q = new Quader();
        q.hoehe = 10;
        q.laenge = 5;
        q.breite = 2;

        System.out.println(q.volumen());
        q.skaliere(6);
        System.out.println(q.grundflaeche());
    }
}
