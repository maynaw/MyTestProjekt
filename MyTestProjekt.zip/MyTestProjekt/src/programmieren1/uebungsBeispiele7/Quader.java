package programmieren1.uebungsBeispiele7;

public class Quader {
    public double laenge;
    public double breite;
    public double hoehe;

    public double grundflaeche(){

        return laenge * breite;
    }
    public void skaliere(double factor){
        laenge *= factor;
        breite *= factor;
        hoehe *= factor;
    }
    public double volumen(){
        return laenge * breite * hoehe;
    }

}
