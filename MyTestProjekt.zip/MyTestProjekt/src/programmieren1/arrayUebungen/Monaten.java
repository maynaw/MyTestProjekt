package programmieren1.arrayUebungen;

public class Monaten {
    public static void main(String[] args) {
        String[] monaten = {"Jänner", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"};
        for (int m = 0; m<monaten.length; m++){
            System.out.println(monaten[m] + " " +(m+1));
        }
    }
}
