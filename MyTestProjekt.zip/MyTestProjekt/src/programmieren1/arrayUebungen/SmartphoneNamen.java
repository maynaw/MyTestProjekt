package programmieren1.arrayUebungen;

import java.util.Arrays;

public class SmartphoneNamen {
    public static void main(String[] args) {

        String[] smartphoneName = {"Samsung A51", "iPhone 13", "Huawei 15", "Nokia 3210", "Xiaomi 7T"};

        int[][] smartphoneVerkaufszahlen = {{2000, 3000, 4000, 1000},
                {1000, 300, 1500, 7000},
                {2200, 300, 4000, 1000},
                {2100, 3000, 4000, 2000},
                {200, 300, 4000, 100}};

        for (int z = 0; z < smartphoneName.length; z++) {
            System.out.print(smartphoneName[z]);
        }
        System.out.println();
        System.out.print(Arrays.toString(smartphoneName));
        System.out.println();

        for (int z = 0; z < smartphoneVerkaufszahlen.length; z++) {
            System.out.print(smartphoneName[z] + ": ");
            for (int s = 0; s < smartphoneVerkaufszahlen[z].length; s++) {
                System.out.print(smartphoneVerkaufszahlen[z][s] + ", ");
            }
            System.out.println();
        }
        System.out.println("----------");
        System.out.println("----------");
        System.out.println("----------");
//        System.out.println(verkaufteAnzahlJahr(smartphoneVerkaufszahlen, -1));
//        System.out.println(verkaufteAnzahlJahr(smartphoneVerkaufszahlen, 5));
//        System.out.println(verkaufteAnzahlJahr(smartphoneVerkaufszahlen, 1));



    }

 //   public static int verkaufteAnzahlJahr(int [][] zahlen, String[] namen, int quartaln)
}