package programmieren1.arrayUebungen;

import java.util.Arrays;

public class Quartale {
    public static void main(String[] args) {
        String[] quartale = {"Frühling", "Sommer", "Herbst", "Winter"};

        String qu1 = quartale[0];
        //qu1.toUpperCase(Locale.ROOT);

        // arrays.tostring erlaubt uns schöne ausgabe - sonst wird Objektreferenz ausgegeben
        System.out.println(Arrays.toString(quartale));

        System.out.println(qu1);
        quartale[0] = "Fru";

        System.out.println(Arrays.toString(quartale));
        System.out.println(qu1);

        int[] array1 = new int[3];
        int[] array2 = {1, 2, 3};

        array1[0] = 3;
        array1[1] = 4;
        array1[2] = 5;

        System.out.print("+: ");
        for (int z = 0; z < array1.length; z++) {
            System.out.print(array1[z] + array2[z]);
            System.out.print(",");
        }

        System.out.println("_________________");
        System.out.print("*: ");
        for (int z = 0; z < array1.length; z++) {
            System.out.print(array1[z] * array2[z]);
            System.out.print(",");
        }
        System.out.println();
        int[][] arr = {{1, 2, 3}, {4, 5, 6}};
        String[][] tage = {{"Mo", "Di", "Mi"}, {"Do", "Fr", "Sa"}};

        for (int z = 0; z < arr.length; z++) {
            for (int s = 0; s < arr[z].length; s++) {
                System.out.print(arr[z][s] + " , ");
                System.out.println(tage[z][s]);

            }
        }
    }
}
