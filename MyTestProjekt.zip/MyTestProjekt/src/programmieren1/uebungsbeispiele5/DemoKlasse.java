package programmieren1.uebungsbeispiele5;

public class DemoKlasse {
    public static void main(String[] args) {
Mitarbeiter neuMitarbeiter = new Mitarbeiter();

neuMitarbeiter.gehalt = 2333.33;
neuMitarbeiter.monatsAbrechnung();
neuMitarbeiter.jahresAbrechnung();
        System.out.println(neuMitarbeiter.monatsAbrechnung());
    }
}
