package programmieren1.uebungsbeispiele5;

public class Mitarbeiter {
        public String vorname;
        public String nachname;
        public double gehalt;
        public int alter;

    public double monatsAbrechnung() {
        return jahresAbrechnung() / 12;
    }
     public double jahresAbrechnung(){
        double jahresGehalt = gehalt *12;
        double gehaltsNachVersicherung = jahresGehalt - (jahresGehalt * 20 / 100);
        double steuer;
        double gehaltsNachSteuer = 0;
         double gehaltProMonat = 0;
        if (gehaltsNachVersicherung <= 10000) {
            steuer = gehaltsNachVersicherung * 10 / 100;
            gehaltsNachSteuer = gehaltsNachVersicherung - steuer;
        }else
        if (gehaltsNachVersicherung <= 20000 && gehaltsNachVersicherung > 10000) {
            steuer = 1000 + ((gehaltsNachVersicherung - 10000) * 20 / 100);
            gehaltsNachSteuer = gehaltsNachVersicherung - steuer;
        }else
        if (gehaltsNachVersicherung <= 30000 && gehaltsNachVersicherung > 20000) {
            steuer = 1000 + 2000 + ((gehaltsNachVersicherung - 20000) * 32 / 100);
            gehaltsNachSteuer = gehaltsNachVersicherung - steuer;
        }else
        if (gehaltsNachVersicherung > 30000 && gehaltsNachVersicherung <= 50000) {
            steuer = 1000 + 2000 + 3200 + ((gehaltsNachVersicherung - 30000) * 45 / 100);
            gehaltsNachSteuer = gehaltsNachVersicherung - steuer;
        }else
        if (gehaltsNachVersicherung > 50000) {
            steuer = 1000 + 2000 + 3200 + 9000 + ((gehaltsNachVersicherung - 50000) * 60 / 100);
            gehaltsNachSteuer = gehaltsNachVersicherung - steuer;
        }
         gehaltProMonat = gehaltsNachSteuer / 12;
       // return gehaltProMonat;
          return gehaltProMonat;
    }

}
