package programmieren1.selbstÜbungOOP;

public class Oop {
    public static void main(String[] args) {
        /*
        User User1 = new User(38, "Mayssa", 160.4);

        User1.infoPrint();

        Student Student1 = new Student();
        Student1.setAge(20);
        Student1.setName("Tara");
        Student1.setHeigh(170);
        Student1.infoPrint();

         */
    }


}

