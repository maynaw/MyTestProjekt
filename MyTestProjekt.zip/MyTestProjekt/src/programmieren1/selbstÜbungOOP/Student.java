package programmieren1.selbstÜbungOOP;
/*
public class Student extends User {
/*

    Student(String name, int age, double heigh) {
        super(name, age, heigh);

 */




