package programmieren1.selbstÜbungOOP;

public class User {
    private int age;
    private String name;
    private double heigh;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHeigh() {
        return heigh;
    }

    public void setHeigh(double heigh) {
        this.heigh = heigh;
    }

    User(int age, String name, double heigh){
        this.name = this.name;
        this.age = age;
        this.heigh = this.heigh;
    }
    void infoPrint() {

        System.out.println("User name is " + name);
        System.out.println("User age is " + age);
        System.out.println("User heigh is " + heigh);
    }
}
