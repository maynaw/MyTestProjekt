package programmieren1.tutorial;

public class SelbstÜbungen {
    public static void main(String[] args) {
        int a = 5;
        float b = 3.1f;
        //first way
        float result = multiple2(a, b);
        System.out.println("result = " + result);

        //second way
        float multipleResult = multiple(2, 2.1f);
        System.out.println("result: " + multipleResult);

        //third way
        int result1 = multiple1();
        System.out.println("result = " + result1);

    }

    public static float multiple(int a, float b) {
        return a * b;
    }

    public static int multiple1() {
        int result1 = 50 * 2;
        return result1;
    }

    public static float multiple2(int a, float b) {
        float result = a * b;
        return result;
    }
}

