package programmieren1.interfaces;

public class InterfacesMainProgramm {
    public static void main(String[] args) {
        Calculator myCalculator = new Calculator();
        myCalculator.add(20, 5);
        myCalculator.multiple(3, 4);
        myCalculator.substruction(20, 7);
    }
}