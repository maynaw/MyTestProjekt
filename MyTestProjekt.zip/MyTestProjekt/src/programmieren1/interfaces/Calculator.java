package programmieren1.interfaces;

public class Calculator {
    public void add(int a, int b) {
        int result = a + b;
        System.out.println(" add result: " + result);
    }

    public void multiple(int a, int b) {
        int result = a * b;
        System.out.println("multiple result: " + result);
    }

    public void substruction(int a, int b) {
        int result = a - b;
        System.out.println(" substruction result: " + result);
    }
}
